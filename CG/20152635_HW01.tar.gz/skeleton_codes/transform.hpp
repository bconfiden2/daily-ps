#ifndef KMUCS_GRAPHICS_TRANSFORM_HPP
#define KMUCS_GRAPHICS_TRANSFORM_HPP

#include <cmath>
#include "vec.hpp"
#include "mat.hpp"
#include "operator.hpp"

namespace kmuvcl
{
    namespace math
    {
#ifndef M_PI
        const float M_PI = 3.14159265358979323846f;
#endif

        template <typename T>
        mat<4, 4, T> translate(T dx, T dy, T dz)
        {
            mat<4, 4, T> translateMat;

            vec<4, T> vecX(1, 0, 0, 0);
            vec<4, T> vecY(0, 1, 0, 0);
            vec<4, T> vecZ(0, 0, 1, 0);
            vec<4, T> transVec(dx,dy,dz,1);

            translateMat.set_ith_column(0, vecX);
            translateMat.set_ith_column(1, vecY);
            translateMat.set_ith_column(2, vecZ);
            translateMat.set_ith_column(3, transVec);

            return translateMat;
        }

        template <typename T>
        mat<4, 4, T> rotate(T angle, T x, T y, T z)
        {
            mat<4, 4, T> rotateMat;
            
            // u축 정규화
            T length = sqrt(x * x + y * y + z * z);
            x /= length;
            y /= length;
            z /= length;
            // 라디안으로 변환
            T rad = angle * (M_PI / 180);

            T cosine = 1 - cos(rad);
            T sine = sin(rad);

            vec<4, T> vecX(cos(rad) + x * x * cosine, x * y * cosine + z * sine, x * z * cosine - y * sine, 0);
            vec<4, T> vecY(x * y * cosine - z * sine, cos(rad) + y * y * cosine, y * z * cosine + x * sine, 0);
            vec<4, T> vecZ(x * z * cosine + y * sine, y * z * cosine - x * sine, cos(rad) + z * z * cosine, 0);
            vec<4, T> vecO(0, 0, 0, 1);

            rotateMat.set_ith_column(0, vecX);
            rotateMat.set_ith_column(1, vecY);
            rotateMat.set_ith_column(2, vecZ);
            rotateMat.set_ith_column(3, vecO);

            return rotateMat;
        }

        template<typename T>
        mat<4, 4, T> scale(T sx, T sy, T sz)
        {
            mat<4, 4, T> scaleMat;

            vec<4, T> vecX(sx, 0, 0, 0);
            vec<4, T> vecY(0, sy, 0, 0);
            vec<4, T> vecZ(0, 0, sz, 0);
            vec<4, T> vecO(0, 0, 0, 1);

            scaleMat.set_ith_column(0, vecX);
            scaleMat.set_ith_column(1, vecY);
            scaleMat.set_ith_column(2, vecZ);
            scaleMat.set_ith_column(3, vecO);

            return scaleMat;
        }

        template<typename T>
        mat<4, 4, T> lookAt(T eyeX, T eyeY, T eyeZ, T centerX, T centerY, T centerZ, T upX, T upY, T upZ)
        {
            mat<4, 4, T> viewMat;
            mat<4, 4, T> posMat = translate(-eyeX, -eyeY, -eyeZ);

            // Z방향 정규화
            T length = sqrt(pow(eyeX - centerX, 2) + pow(eyeY - centerY, 2) + pow(eyeZ - centerZ, 2));
            vec<3, T> dirZ((eyeX - centerX) / length, (eyeY - centerY) / length, (eyeZ - centerZ) / length);
            // 주어진 up방향 정규화
            length = sqrt(pow(upX, 2) + pow(upY, 2) + pow(upZ, 2));
            vec<3, T> dirY(upX / length, upY / length, upZ / length);
            // Z방향 up방향 외적 후 정규화 -> X방향
            vec<3, T> dirX = math::cross(dirY, dirZ);
            length = sqrt(pow(dirX(0), 2) + pow(dirX(1), 2) + pow(dirX(2), 2));
            dirX = vec<3, T>(dirX(0) / length, dirX(1) / length, dirX(2) / length);
            // Z방향 X방향 외적 후 정규화 -> Y방향
            dirY = math::cross(dirZ, dirX);
            length = sqrt(pow(dirY(0), 2) + pow(dirY(1), 2) + pow(dirY(2), 2));
            dirY = vec<3, T>(dirY(0) / length, dirY(1) / length, dirY(2) / length);

            vec<4, T> vecX(dirX(0), dirX(1), dirX(2), 0);
            vec<4, T> vecY(dirY(0), dirY(1), dirY(2), 0);
            vec<4, T> vecZ(dirZ(0), dirZ(1), dirZ(2), 0);
            vec<4, T> vecO(0, 0, 0, 1);

            viewMat.set_ith_column(0, vecX);
            viewMat.set_ith_column(1, vecY);
            viewMat.set_ith_column(2, vecZ);
            viewMat.set_ith_column(3, vecO);

            viewMat = viewMat * posMat;
            return viewMat;
        }

        template<typename T>
        mat<4, 4, T> ortho(T left, T right, T bottom, T top, T nearVal, T farVal)
        {
            mat<4, 4, T> orthoMat;
            
            vec<4, T> vecX(2 / (right - left), 0, 0, 0);
            vec<4, T> vecY(0, 2 / (top - bottom), 0, 0);
            vec<4, T> vecZ(0, 0, -2 / (farVal - nearVal), 0);
            vec<4, T> vecO(-(right + left) / (right - left), -(top + bottom) / (top - bottom), -(farVal + nearVal) / (farVal - nearVal), 1);

            orthoMat.set_ith_column(0, vecX);
            orthoMat.set_ith_column(1, vecY);
            orthoMat.set_ith_column(2, vecZ);
            orthoMat.set_ith_column(3, vecO);

            return orthoMat;
        }

        template<typename T>
        mat<4, 4, T> frustum(T left, T right, T bottom, T top, T nearVal, T farVal)
        {
            mat<4, 4, T> frustumMat;

            vec<4, T> vecX((2 * nearVal) / (right - left), 0, 0, 0);
            vec<4, T> vecY(0, (2 * nearVal) / (top - bottom), 0, 0);
            vec<4, T> vecZ((right + left) / (right - left), (top + bottom) / (top - bottom), -(farVal + nearVal) / (farVal - nearVal), -1);
            vec<4, T> vecO(0, 0, (-2 * farVal * nearVal) / (farVal - nearVal), 0);

            frustumMat.set_ith_column(0, vecX);
            frustumMat.set_ith_column(1, vecY);
            frustumMat.set_ith_column(2, vecZ);
            frustumMat.set_ith_column(3, vecO);

            return frustumMat;
        }

        template<typename T>
        mat<4, 4, T> perspective(T fovy, T aspect, T zNear, T zFar)
        {
            T  right = 0;
            T  top = 0;

            // 절반 각도
            T rad = fovy * (M_PI / 360);
            
            top = zNear * tan(rad);
            right = aspect * top;

            return frustum(-right, right, -top, top, zNear, zFar);
        }
    }
}
#endif
